def hello() -> str:
    return "Hello from lumina-backend!"
